#/bin/bash

FICHIERS_HTML="/work"
SORTIE="resultats"

mkdir -p "$SORTIE"

for fic in "$FICHIERS_HTML"/*.html
do
    base=$(basename "$fic")
    nomfic=$fic
    nomsortie="${base%.html}"


    weasyprint "$nomfic" "$SORTIE/$nomsortie.pdf"

done
