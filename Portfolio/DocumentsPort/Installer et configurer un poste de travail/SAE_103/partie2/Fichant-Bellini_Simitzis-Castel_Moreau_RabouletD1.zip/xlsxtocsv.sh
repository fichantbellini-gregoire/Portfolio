#!/usr/bin/bash
rm *.csv
nbFichier=$(ls *.xlsx 2>/dev/null | wc -l)
if [ "$nbFichier" -gt 0 ];
then
    docker run --rm -dit --name excel2csv bigpapoo/sae103-excel2csv 

    for files in *.xlsx
    do
        filescsv="${files%.xlsx}.csv"
        
        docker container cp $files excel2csv:/app
        docker container exec -it excel2csv ssconvert $files $filescsv
        docker container cp excel2csv:/app/$filescsv .
        echo $filescsv
        
    done
fi
docker stop excel2csv
