$titre = explode(",",tab[0]);
    $titre = str_replace('"',"",$titre[0]);
    echo "<h1>$titre</h1>";

    echo "<tables>";

    echo "<thead>";
    $thead = explode(",",$tab[2]);
    echo "<tr>";
    echo "<th scope=\"col\"$thead[0]</th>";
    echo "<th scope=\"col\"$thead[1]</th>";
    echo "<th scope=\"col\"$thead[2]</th>";
    echo "</tr>";
    echo "</thead>";

    echo "<tbody>";
    foreach(array_slice($tab, 3)as $ldgTab){
        $lstLigne = explode(",",$ldgTab);

        $nomDep = str_replace('"',"",trim($lstLigne[0]));
        $codePostal = trim($lstLigne[1]); 
        $nbVisiteur = trim($lstLigne[2]);

        echo "<tr>";
        echo "<th scope=\"col\"$nomDep</th>";
        echo "<td>$codePostal</td>";
        echo "<td>$nbVisiteur</td>";
        echo "</tr>";
    }
    echo "</tbody>";
    echo "</table>";
?>
