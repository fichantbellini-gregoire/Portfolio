#!/bin/bash


docker container run --rm -dt --name images bigpapoo/imagick
for fichiers in *.jpg *.png
do
    docker container cp ./"$fichiers" images:/work
done 
docker container cp ./traitement.sh images:/work
docker container exec images mkdir -p /work/Images_non_conformes
docker container exec images mkdir -p /work/Images_conformes
docker container exec images bash /work/traitement.sh
docker container cp images:/work/Images_conformes .
docker container cp images:/work/Images_non_conformes .
docker container stop images
