<?php

$fichiers = glob("*.txt");


if (!is_dir("resultats")) {
    mkdir("resultats");
}


foreach ($fichiers as $fichier) {


    $lignes = file($fichier);

    
    $nom_html = "resultats/" . basename($fichier, ".txt") . ".html";

    $sortie = fopen($nom_html, "w");

    fwrite($sortie, "<h1>" . $lignes[0] . "</h1>\n");

  
    for ($i = 1; $i < count($lignes); $i++) {
        fwrite($sortie, "<p>" . $lignes[$i] . "</p>\n");
    }

    fclose($sortie);
}
?>
