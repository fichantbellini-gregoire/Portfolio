#/bin/bash

docker container run -d -t --name "html2pdf" bigpapoo/sae103-html2pdf


for fic in *.html
do
    docker container cp $fic html2pdf:/work
done

docker container cp container.sh html2pdf:work
docker exec html2pdf bash ./container.sh

docker cp html2pdf:/work/resultats .

docker container stop html2pdf
docker rm html2pdf
